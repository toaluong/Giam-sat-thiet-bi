﻿using LabManager.Shared.Helpers;
using LabManager.Shared.Models;
using System;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace LabManager.Client
{
    public class ClientAgent
    {
        private TcpClient _tcp;
        private NetworkStream _stream;
        private string _clientId;
        private CancellationTokenSource _cts = new();

        public async Task StartAsync()
        {
            Console.WriteLine("🔍 Đang tìm Server trong mạng LAN...");
            string serverIp = await DiscoverServer();

            if (string.IsNullOrEmpty(serverIp))
            {
                Console.WriteLine("❌ Không tìm thấy Server. Thử lại sau 5 giây...");
                await Task.Delay(5000);
                await StartAsync();
                return;
            }

            Console.WriteLine($"✅ Tìm thấy Server tại {serverIp}:8888");

            // Kết nối TCP
            _tcp = new TcpClient();
            await _tcp.ConnectAsync(serverIp, 8888);
            _stream = _tcp.GetStream();

            // Đăng ký
            await Register();
            Console.WriteLine($"✅ Đăng ký thành công! Client ID: {_clientId}");

            // Chạy các tác vụ song song
            var tasks = new[]
            {
                SendHeartbeatAsync(),
                SendResourceReportAsync(),
                SendScreenCaptureAsync(),
                ReceiveCommandsAsync()
            };

            await Task.WhenAny(tasks);
        }

        private async Task<string> DiscoverServer()
        {
            using var udp = new UdpClient();
            udp.EnableBroadcast = true;
            var broadcast = new IPEndPoint(IPAddress.Broadcast, 9999);

            byte[] data = System.Text.Encoding.UTF8.GetBytes("DISCOVER_SERVER");
            await udp.SendAsync(data, data.Length, broadcast);

            var receiveTask = udp.ReceiveAsync();
            var timeout = Task.Delay(3000);
            var completed = await Task.WhenAny(receiveTask, timeout);

            if (completed == receiveTask)
            {
                var result = await receiveTask;
                string response = System.Text.Encoding.UTF8.GetString(result.Buffer);
                if (response == "SERVER_FOUND")
                {
                    return result.RemoteEndPoint.Address.ToString();
                }
            }
            return null;
        }

        private async Task Register()
        {
            var info = new SystemInfo
            {
                MachineName = Environment.MachineName,
                IpAddress = GetLocalIP(),
                OSVersion = Environment.OSVersion.VersionString,
                CpuCores = Environment.ProcessorCount,
                TotalRAM = GetTotalRAM()
            };

                var packet = new Packet
                {
                    Command = LabManager.Shared.Models.CommandType.Register,
                    Payload = info
                };

            byte[] data = NetworkHelper.Serialize(packet);
            await NetworkHelper.SendWithLengthAsync(_stream, data);

            // Nhận phản hồi từ Server
            byte[] responseData = await NetworkHelper.ReceiveWithLengthAsync(_stream);
            if (responseData != null)
            {
                var response = NetworkHelper.Deserialize<Packet>(responseData);
                _clientId = response.ClientId;
            }
        }

        private async Task SendHeartbeatAsync()
        {
            while (!_cts.IsCancellationRequested)
            {
                await Task.Delay(3000);
                try
                {
                    var packet = new Packet
                    {
                        Command = LabManager.Shared.Models.CommandType.Heartbeat,
                        ClientId = _clientId
                    };
                    byte[] data = NetworkHelper.Serialize(packet);
                    await NetworkHelper.SendWithLengthAsync(_stream, data);
                }
                catch { break; }
            }
        }

        private async Task SendResourceReportAsync()
        {
            while (!_cts.IsCancellationRequested)
            {
                await Task.Delay(5000);
                try
                {
                    var report = new ResourceReport
                    {
                        CPUUsage = GetCPUUsage(),
                        RAMUsage = GetRAMUsage(),
                        DiskUsage = GetDiskUsage(),
                        RunningProcesses = GetTopProcesses(5)
                    };

                    var packet = new Packet
                    {
                        Command = LabManager.Shared.Models.CommandType.ResourceReport,
                        ClientId = _clientId,
                        Payload = report
                    };

                    byte[] data = NetworkHelper.Serialize(packet);
                    await NetworkHelper.SendWithLengthAsync(_stream, data);
                }
                catch { break; }
            }
        }

        private async Task SendScreenCaptureAsync()
        {
            while (!_cts.IsCancellationRequested)
            {
                await Task.Delay(1000);
                try
                {
                    using var bitmap = CaptureScreen();
                    byte[] jpegData = ConvertToJPEG(bitmap, 60);

                    var frame = new ScreenFrame
                    {
                        ImageData = jpegData,
                        Width = bitmap.Width,
                        Height = bitmap.Height,
                        CaptureTime = DateTime.Now
                    };

                    var packet = new Packet
                    {
                        Command = LabManager.Shared.Models.CommandType.ScreenFrame,
                        ClientId = _clientId,
                        Payload = frame
                    };

                    byte[] data = NetworkHelper.Serialize(packet);
                    await NetworkHelper.SendWithLengthAsync(_stream, data);
                }
                catch { break; }
            }
        }

        private async Task ReceiveCommandsAsync()
        {
            while (!_cts.IsCancellationRequested)
            {
                try
                {
                    byte[] data = await NetworkHelper.ReceiveWithLengthAsync(_stream);
                    if (data == null) break;

                    var packet = NetworkHelper.Deserialize<Packet>(data);
                    await ExecuteCommand(packet);
                }
                catch { break; }
            }
        }

        private async Task ExecuteCommand(Packet packet)
        {
            Console.WriteLine($"📨 Nhận lệnh từ Server: {packet.Command}");

            switch (packet.Command)
            {
                case LabManager.Shared.Models.CommandType.LockScreen:
                    LockWorkStation();
                    Console.WriteLine("🔒 Đã khóa màn hình");
                    break;

                case LabManager.Shared.Models.CommandType.UnlockScreen:
                    Console.WriteLine("🔓 Mở khóa màn hình (không hỗ trợ)");
                    break;

                case LabManager.Shared.Models.CommandType.Shutdown:
                    Console.WriteLine("⏻ Đang tắt máy...");
                    await ShutdownComputer();
                    break;

                case LabManager.Shared.Models.CommandType.ShutdownTimer:
                    int seconds = Convert.ToInt32(packet.Payload);
                    Console.WriteLine($"⏰ Hẹn giờ tắt máy sau {seconds} giây");
                    await ShutdownWithTimer(seconds);
                    break;

                case LabManager.Shared.Models.CommandType.KillProcess:
                    string processName = packet.Payload?.ToString();
                    if (!string.IsNullOrEmpty(processName))
                    {
                        KillProcess(processName);
                    }
                    break;

                case LabManager.Shared.Models.CommandType.RunApplication:
                    string appPath = packet.Payload?.ToString();
                    if (!string.IsNullOrEmpty(appPath))
                    {
                        Process.Start(appPath);
                        Console.WriteLine($"🚀 Đã chạy ứng dụng: {appPath}");
                    }
                    break;

                case LabManager.Shared.Models.CommandType.ShowNotification:
                    string message = packet.Payload?.ToString();
                    if (!string.IsNullOrEmpty(message))
                    {
                        ShowNotification(message);
                    }
                    break;

                case LabManager.Shared.Models.CommandType.ReceiveFile:
                    var filePayload = packet.Payload as dynamic;
                    if (filePayload != null)
                    {
                        string fileName = filePayload.FileName;
                        byte[] fileData = filePayload.Data;
                        await ReceiveFile(fileName, fileData);
                    }
                    break;
            }
        }

        // ==================== HÀM HỖ TRỢ ====================

        private float GetCPUUsage()
        {
            try
            {
                var cpuCounter = new PerformanceCounter("Processor", "% Processor Time", "_Total");
                cpuCounter.NextValue();
                Thread.Sleep(100);
                return cpuCounter.NextValue();
            }
            catch { return 0; }
        }

        private float GetRAMUsage()
        {
            try
            {
                var memCounter = new PerformanceCounter("Memory", "Available MBytes");
                float available = memCounter.NextValue();
                float total = GetTotalRAM();
                return ((total - available) / total) * 100;
            }
            catch { return 0; }
        }

        private float GetDiskUsage()
        {
            try
            {
                var drive = new DriveInfo("C:");
                long total = drive.TotalSize;
                long free = drive.TotalFreeSpace;
                return ((float)(total - free) / total) * 100;
            }
            catch { return 0; }
        }

        private long GetTotalRAM()
        {
            try
            {
                var memCounter = new PerformanceCounter("Memory", "Available MBytes");
                return (long)memCounter.NextValue();
            }
            catch { return 8192; }
        }

        private List<string> GetTopProcesses(int count)
        {
            try
            {
                return Process.GetProcesses()
                    .OrderByDescending(p => p.WorkingSet64)
                    .Take(count)
                    .Select(p => p.ProcessName)
                    .ToList();
            }
            catch { return new List<string>(); }
        }

        private Bitmap CaptureScreen()
        {
            var bounds = System.Windows.Forms.Screen.PrimaryScreen.Bounds;
            var bitmap = new Bitmap(bounds.Width, bounds.Height);
            using (var g = Graphics.FromImage(bitmap))
            {
                g.CopyFromScreen(Point.Empty, Point.Empty, bounds.Size);
            }
            return bitmap;
        }

        private byte[] ConvertToJPEG(Bitmap bitmap, int quality)
        {
            using var ms = new MemoryStream();
            var encoderParams = new EncoderParameters(1);
            encoderParams.Param[0] = new EncoderParameter(System.Drawing.Imaging.Encoder.Quality, quality);

            var codec = ImageCodecInfo.GetImageEncoders()
                .First(c => c.MimeType == "image/jpeg");

            bitmap.Save(ms, codec, encoderParams);
            return ms.ToArray();
        }

        private string GetLocalIP()
        {
            var host = Dns.GetHostEntry(Dns.GetHostName());
            return host.AddressList
                .FirstOrDefault(ip => ip.AddressFamily == AddressFamily.InterNetwork)
                ?.ToString() ?? "127.0.0.1";
        }

        [DllImport("user32.dll")]
        private static extern void LockWorkStation();

        private async Task ShutdownComputer()
        {
            Process.Start("shutdown", "/s /t 0");
            await Task.CompletedTask;
        }

        private async Task ShutdownWithTimer(int seconds)
        {
            Process.Start("shutdown", $"/s /t {seconds}");
            await Task.CompletedTask;
        }

        private void KillProcess(string processName)
        {
            try
            {
                var processes = Process.GetProcessesByName(processName);
                foreach (var p in processes)
                {
                    p.Kill();
                    Console.WriteLine($"✅ Đã đóng {processName}");
                }
                if (processes.Length == 0)
                {
                    Console.WriteLine($"⚠️ Không tìm thấy ứng dụng {processName}");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Không thể đóng {processName}: {ex.Message}");
            }
        }

        private void ShowNotification(string message)
        {
            Console.WriteLine($"📢 THÔNG BÁO TỪ GIẢNG VIÊN: {message}");
            // Có thể dùng MessageBox cho Windows Forms
        }

        private async Task ReceiveFile(string fileName, byte[] fileData)
        {
            try
            {
                string desktopPath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
                string savePath = Path.Combine(desktopPath, fileName);
                await File.WriteAllBytesAsync(savePath, fileData);
                Console.WriteLine($"📁 Đã nhận file {fileName} lưu tại {savePath}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Lỗi lưu file: {ex.Message}");
            }
        }
    }
}