﻿using System;
using System.Threading.Tasks;

namespace LabManager.Client
{
    class Program
    {
        static async Task Main(string[] args)
        {
            Console.WriteLine("🖥️  UTH Client Agent - Máy Sinh Viên");
            Console.WriteLine("=====================================");
            Console.WriteLine();

            var client = new ClientAgent();
            await client.StartAsync();

            Console.WriteLine();
            Console.WriteLine("Client đã dừng. Nhấn phím bất kỳ để thoát...");
            Console.ReadKey();
        }
    }
}