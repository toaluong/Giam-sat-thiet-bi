﻿using LabManager.Shared.Helpers;
using LabManager.Shared.Models;
using System;
using System.Data;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.Threading.Tasks;

namespace LabManager.Server
{
    public class ClientSession
    {
        private TcpClient _client;
        private NetworkStream _stream;
        private CancellationTokenSource _cts = new();

        public string SessionId { get; } = Guid.NewGuid().ToString().Substring(0, 8);
        public string IpAddress { get; }
        public SystemInfo Info { get; private set; }
        public ScreenFrame LastFrame { get; private set; }
        public DateTime LastHeartbeat { get; private set; } = DateTime.Now;

        public event Action<ClientSession, SystemInfo> OnSystemInfo;
        public event Action<ClientSession, ScreenFrame> OnScreenFrame;
        public event Action<ClientSession> OnDisconnected;

        public ClientSession(TcpClient client)
        {
            _client = client;
            IpAddress = ((IPEndPoint)client.Client.RemoteEndPoint).Address.ToString();
            _stream = client.GetStream();
        }

        public NetworkStream GetStream() => _stream;

        public void Start()
        {
            _ = Task.Run(ProcessMessages);
        }

        private async Task ProcessMessages()
        {
            try
            {
                while (!_cts.IsCancellationRequested && _client.Connected)
                {
                    byte[] data = await NetworkHelper.ReceiveWithLengthAsync(_stream);
                    if (data == null) break;

                    var packet = NetworkHelper.Deserialize<Packet>(data);
                    await HandlePacket(packet);
                }
            }
            catch { }
            finally
            {
                _client?.Close();
                OnDisconnected?.Invoke(this);
            }
        }

        private async Task HandlePacket(Packet packet)
        {
            LastHeartbeat = DateTime.Now;

            switch (packet.Command)
            {
                case LabManager.Shared.Models.CommandType.Register:
                    Info = (SystemInfo)packet.Payload;
                    OnSystemInfo?.Invoke(this, Info);
                    await SendCommand(LabManager.Shared.Models.CommandType.Register, new { ClientId = SessionId });
                    break;

                case LabManager.Shared.Models.CommandType.Heartbeat:
                    // Cập nhật heartbeat
                    break;

                case LabManager.Shared.Models.CommandType.ResourceReport:
                    Console.WriteLine($"[SESSION] {SessionId}: Resource report received");
                    break;

                case LabManager.Shared.Models.CommandType.ScreenFrame:
                    LastFrame = (ScreenFrame)packet.Payload;
                    OnScreenFrame?.Invoke(this, LastFrame);
                    break;
            }
        }

        public async Task SendCommand(LabManager.Shared.Models.CommandType command, object payload = null)
        {
            try
            {
                var packet = new Packet
                {
                    Command = command,
                    ClientId = SessionId,
                    Payload = payload
                };
                byte[] data = NetworkHelper.Serialize(packet);
                await NetworkHelper.SendWithLengthAsync(_stream, data);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[SESSION] Send error: {ex.Message}");
            }
        }

        public void Stop() => _cts.Cancel();
    }
}