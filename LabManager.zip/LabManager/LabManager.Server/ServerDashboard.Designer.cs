﻿namespace LabManager.Server
{
    partial class ServerDashboard
    {
        private System.ComponentModel.IContainer components = null;

        // Khai báo các control
        private System.Windows.Forms.PictureBox pictureBoxGrid;
        private System.Windows.Forms.Label lblStatus;
        private System.Windows.Forms.Button btnLockAll;
        private System.Windows.Forms.Button btnShutdownAll;
        private System.Windows.Forms.Button btnKillApp;
        private System.Windows.Forms.Button btnNotify;
        private System.Windows.Forms.Button btnSendFile;
        private System.Windows.Forms.Panel panelControls;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.pictureBoxGrid = new System.Windows.Forms.PictureBox();
            this.lblStatus = new System.Windows.Forms.Label();
            this.panelControls = new System.Windows.Forms.Panel();
            this.btnSendFile = new System.Windows.Forms.Button();
            this.btnNotify = new System.Windows.Forms.Button();
            this.btnKillApp = new System.Windows.Forms.Button();
            this.btnShutdownAll = new System.Windows.Forms.Button();
            this.btnLockAll = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxGrid)).BeginInit();
            this.panelControls.SuspendLayout();
            this.SuspendLayout();

            // pictureBoxGrid
            this.pictureBoxGrid.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBoxGrid.Location = new System.Drawing.Point(0, 0);
            this.pictureBoxGrid.Name = "pictureBoxGrid";
            this.pictureBoxGrid.Size = new System.Drawing.Size(1000, 770);
            this.pictureBoxGrid.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxGrid.TabIndex = 0;
            this.pictureBoxGrid.TabStop = false;

            // lblStatus
            this.lblStatus.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.lblStatus.BackColor = System.Drawing.Color.LightGray;
            this.lblStatus.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.lblStatus.Location = new System.Drawing.Point(0, 770);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(1000, 30);
            this.lblStatus.TabIndex = 1;
            this.lblStatus.Text = "🖥️ Đang khởi động...";
            this.lblStatus.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;

            // panelControls
            this.panelControls.Controls.Add(this.btnSendFile);
            this.panelControls.Controls.Add(this.btnNotify);
            this.panelControls.Controls.Add(this.btnKillApp);
            this.panelControls.Controls.Add(this.btnShutdownAll);
            this.panelControls.Controls.Add(this.btnLockAll);
            this.panelControls.Dock = System.Windows.Forms.DockStyle.Right;
            this.panelControls.Location = new System.Drawing.Point(1000, 0);
            this.panelControls.Name = "panelControls";
            this.panelControls.Size = new System.Drawing.Size(200, 800);
            this.panelControls.TabIndex = 2;

            // btnSendFile
            this.btnSendFile.BackColor = System.Drawing.Color.FromArgb(52, 152, 219);
            this.btnSendFile.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSendFile.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnSendFile.ForeColor = System.Drawing.Color.White;
            this.btnSendFile.Location = new System.Drawing.Point(10, 210);
            this.btnSendFile.Name = "btnSendFile";
            this.btnSendFile.Size = new System.Drawing.Size(180, 40);
            this.btnSendFile.TabIndex = 0;
            this.btnSendFile.Text = "📁 Gửi file";
            this.btnSendFile.UseVisualStyleBackColor = false;
            this.btnSendFile.Click += new System.EventHandler(this.BtnSendFile_Click);

            // btnNotify
            this.btnNotify.BackColor = System.Drawing.Color.FromArgb(52, 152, 219);
            this.btnNotify.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNotify.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnNotify.ForeColor = System.Drawing.Color.White;
            this.btnNotify.Location = new System.Drawing.Point(10, 160);
            this.btnNotify.Name = "btnNotify";
            this.btnNotify.Size = new System.Drawing.Size(180, 40);
            this.btnNotify.TabIndex = 0;
            this.btnNotify.Text = "💬 Gửi thông báo";
            this.btnNotify.UseVisualStyleBackColor = false;
            this.btnNotify.Click += new System.EventHandler(this.BtnNotify_Click);

            // btnKillApp
            this.btnKillApp.BackColor = System.Drawing.Color.FromArgb(52, 152, 219);
            this.btnKillApp.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnKillApp.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnKillApp.ForeColor = System.Drawing.Color.White;
            this.btnKillApp.Location = new System.Drawing.Point(10, 110);
            this.btnKillApp.Name = "btnKillApp";
            this.btnKillApp.Size = new System.Drawing.Size(180, 40);
            this.btnKillApp.TabIndex = 0;
            this.btnKillApp.Text = "✖ Đóng ứng dụng";
            this.btnKillApp.UseVisualStyleBackColor = false;
            this.btnKillApp.Click += new System.EventHandler(this.BtnKillApp_Click);

            // btnShutdownAll
            this.btnShutdownAll.BackColor = System.Drawing.Color.FromArgb(52, 152, 219);
            this.btnShutdownAll.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnShutdownAll.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnShutdownAll.ForeColor = System.Drawing.Color.White;
            this.btnShutdownAll.Location = new System.Drawing.Point(10, 60);
            this.btnShutdownAll.Name = "btnShutdownAll";
            this.btnShutdownAll.Size = new System.Drawing.Size(180, 40);
            this.btnShutdownAll.TabIndex = 0;
            this.btnShutdownAll.Text = "⏻ Tắt máy";
            this.btnShutdownAll.UseVisualStyleBackColor = false;
            this.btnShutdownAll.Click += new System.EventHandler(this.BtnShutdownAll_Click);

            // btnLockAll
            this.btnLockAll.BackColor = System.Drawing.Color.FromArgb(52, 152, 219);
            this.btnLockAll.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLockAll.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnLockAll.ForeColor = System.Drawing.Color.White;
            this.btnLockAll.Location = new System.Drawing.Point(10, 10);
            this.btnLockAll.Name = "btnLockAll";
            this.btnLockAll.Size = new System.Drawing.Size(180, 40);
            this.btnLockAll.TabIndex = 0;
            this.btnLockAll.Text = "🔒 Khóa màn hình";
            this.btnLockAll.UseVisualStyleBackColor = false;
            this.btnLockAll.Click += new System.EventHandler(this.BtnLockAll_Click);

            // ServerDashboard
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1200, 800);
            this.Controls.Add(this.pictureBoxGrid);
            this.Controls.Add(this.lblStatus);
            this.Controls.Add(this.panelControls);
            this.Name = "ServerDashboard";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "📊 UTH Server - Giám sát phòng thi";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxGrid)).EndInit();
            this.panelControls.ResumeLayout(false);
            this.ResumeLayout(false);
        }
    }
}