﻿using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using LabManager.Shared.Models;

namespace LabManager.Server
{
    public partial class ServerDashboard : Form
    {
        private ServerManager _server;
        private System.Windows.Forms.Timer _uiTimer;

        // Các control sẽ được khởi tạo trong InitializeComponent (ở file Designer)
        // Nên khai báo ở đây để dùng trong code

        public ServerDashboard()
        {
            InitializeComponent(); // Gọi hàm từ file Designer

            _server = new ServerManager();
            _server.OnClientConnected += (s) => UpdateUI();
            _server.OnClientDisconnected += (id) => UpdateUI();
            _server.OnScreenFrame += (s, f) => UpdateUI();

            _ = _server.StartAsync();

            _uiTimer = new System.Windows.Forms.Timer { Interval = 1000 };
            _uiTimer.Tick += (s, e) => UpdateUI();
            _uiTimer.Start();
        }

        // Hàm cập nhật giao diện
        private void UpdateUI()
        {
            var clients = _server.GetActiveClients();
            lblStatus.Text = $"🖥️ Số máy đang kết nối: {clients.Count}";

            if (clients.Count > 0)
            {
                int cols = 4;
                int rows = (int)Math.Ceiling(clients.Count / (double)cols);
                int thumbWidth = 250;
                int thumbHeight = 180;

                using var grid = new Bitmap(cols * thumbWidth, rows * thumbHeight);
                using var g = Graphics.FromImage(grid);
                g.Clear(Color.Black);

                for (int i = 0; i < clients.Count && i < 16; i++)
                {
                    var client = clients[i];
                    int row = i / cols;
                    int col = i % cols;

                    if (client.LastFrame?.ImageData != null)
                    {
                        using var ms = new System.IO.MemoryStream(client.LastFrame.ImageData);
                        using var img = Image.FromStream(ms);
                        g.DrawImage(img, col * thumbWidth, row * thumbHeight, thumbWidth, thumbHeight);
                    }
                    else
                    {
                        g.FillRectangle(Brushes.DarkGray, col * thumbWidth, row * thumbHeight, thumbWidth, thumbHeight);
                        g.DrawString($"{client.SessionId}", new Font("Arial", 14), Brushes.White,
                            col * thumbWidth + 10, row * thumbHeight + 10);
                        g.DrawString("⏳ Chờ ảnh...", new Font("Arial", 12), Brushes.LightGray,
                            col * thumbWidth + 10, row * thumbHeight + 50);
                    }
                }

                pictureBoxGrid.Image?.Dispose();
                pictureBoxGrid.Image = new Bitmap(grid);
            }
        }

        // Các sự kiện click cho button
        private void BtnLockAll_Click(object sender, EventArgs e)
        {
            _server.BroadcastCommand(CommandType.LockScreen);
        }

        private void BtnShutdownAll_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Tắt tất cả máy sinh viên?", "Xác nhận",
                MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                _server.BroadcastCommand(CommandType.Shutdown);
            }
        }

        private void BtnKillApp_Click(object sender, EventArgs e)
        {
            string app = InputBox.Show("Tên ứng dụng cần đóng:", "Đóng ứng dụng");
            if (!string.IsNullOrEmpty(app))
            {
                _server.BroadcastCommand(CommandType.KillProcess, app);
            }
        }

        private void BtnNotify_Click(object sender, EventArgs e)
        {
            string msg = InputBox.Show("Nội dung thông báo:", "Thông báo");
            if (!string.IsNullOrEmpty(msg))
            {
                _server.BroadcastCommand(CommandType.ShowNotification, msg);
            }
        }

        private void BtnSendFile_Click(object sender, EventArgs e)
        {
            using var dialog = new OpenFileDialog();
            dialog.Title = "Chọn file để gửi đến sinh viên";
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                _server.BroadcastFile(dialog.FileName);
            }
        }

        // Hàm InputBox
        public static class InputBox
        {
            public static string Show(string prompt, string title)
            {
                var form = new Form
                {
                    Text = title,
                    Size = new Size(400, 150),
                    StartPosition = FormStartPosition.CenterParent
                };
                var label = new Label { Text = prompt, Left = 20, Top = 20, Width = 350 };
                var textBox = new TextBox { Left = 20, Top = 50, Width = 350 };
                var button = new Button { Text = "OK", Left = 280, Width = 90, Top = 80 };
                button.Click += (s, e) => form.Close();

                form.Controls.Add(label);
                form.Controls.Add(textBox);
                form.Controls.Add(button);
                form.ShowDialog();

                return textBox.Text;
            }
        }
    }
}