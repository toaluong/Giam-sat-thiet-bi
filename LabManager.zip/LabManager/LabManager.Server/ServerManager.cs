﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.Threading.Tasks;
using LabManager.Shared.Models;
using LabManager.Shared.Helpers;

namespace LabManager.Server  // ← Namespace phải khớp với ServerDashboard
{
    public class ServerManager
    {
        private TcpListener _listener;
        private UdpClient _udpBroadcast;
        private ConcurrentDictionary<string, ClientSession> _sessions = new();
        private CancellationTokenSource _cts = new();

        public event Action<ClientSession> OnClientConnected;
        public event Action<ClientSession, SystemInfo> OnSystemInfo;
        public event Action<ClientSession, ScreenFrame> OnScreenFrame;
        public event Action<string> OnClientDisconnected;

        public async Task StartAsync(int port = 8888)
        {
            _listener = new TcpListener(IPAddress.Any, port);
            _listener.Start();
            Console.WriteLine($"[SERVER] TCP Server started on port {port}");

            _udpBroadcast = new UdpClient(9999);
            _ = Task.Run(HandleUdpBroadcast);

            await AcceptClients();
        }

        private async Task AcceptClients()
        {
            try
            {
                while (!_cts.IsCancellationRequested)
                {
                    var tcp = await _listener.AcceptTcpClientAsync();
                    tcp.NoDelay = true;
                    var session = new ClientSession(tcp);

                    session.OnSystemInfo += (s, info) => OnSystemInfo?.Invoke(s, info);
                    session.OnScreenFrame += (s, frame) => OnScreenFrame?.Invoke(s, frame);
                    session.OnDisconnected += (s) => RemoveSession(s.SessionId);

                    _sessions[session.SessionId] = session;
                    session.Start();
                    OnClientConnected?.Invoke(session);
                    Console.WriteLine($"[SERVER] Client connected: {session.IpAddress}");
                }
            }
            catch (OperationCanceledException) { }
            catch (Exception ex)
            {
                Console.WriteLine($"[SERVER] Accept error: {ex.Message}");
            }
        }

        private async Task HandleUdpBroadcast()
        {
            while (!_cts.IsCancellationRequested)
            {
                try
                {
                    var result = await _udpBroadcast.ReceiveAsync();
                    string msg = System.Text.Encoding.UTF8.GetString(result.Buffer);
                    if (msg == "DISCOVER_SERVER")
                    {
                        byte[] response = System.Text.Encoding.UTF8.GetBytes("SERVER_FOUND");
                        await _udpBroadcast.SendAsync(response, response.Length, result.RemoteEndPoint);
                        Console.WriteLine($"[SERVER] UDP response sent to {result.RemoteEndPoint}");
                    }
                }
                catch { }
            }
        }

        public void RemoveSession(string sessionId)
        {
            if (_sessions.TryRemove(sessionId, out var session))
            {
                session.Stop();
                OnClientDisconnected?.Invoke(sessionId);
                Console.WriteLine($"[SERVER] Client disconnected: {session.IpAddress}");
            }
        }

        public async Task BroadcastCommand(CommandType command, object payload = null, string[] targetIds = null)
        {
            var targets = targetIds ?? _sessions.Keys.ToArray();
            foreach (var id in targets)
            {
                if (_sessions.TryGetValue(id, out var session))
                {
                    await session.SendCommand(command, payload);
                    Console.WriteLine($"[SERVER] Command {command} sent to {id}");
                }
            }
        }

        public async Task BroadcastFile(string filePath, string[] targetIds = null)
        {
            byte[] fileData = System.IO.File.ReadAllBytes(filePath);
            string fileName = System.IO.Path.GetFileName(filePath);
            var targets = targetIds ?? _sessions.Keys.ToArray();

            foreach (var id in targets)
            {
                if (_sessions.TryGetValue(id, out var session))
                {
                    var payload = new
                    {
                        FileName = fileName,
                        Data = fileData
                    };
                    await session.SendCommand(CommandType.ReceiveFile, payload);
                    Console.WriteLine($"[SERVER] File {fileName} sent to {id}");
                }
            }
        }

        public List<ClientSession> GetActiveClients()
        {
            return _sessions.Values.ToList();
        }

        public void Stop() => _cts.Cancel();
    }
}