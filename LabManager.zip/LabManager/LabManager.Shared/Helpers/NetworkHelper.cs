﻿using System;
using System.IO;
using System.Net.Sockets;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace LabManager.Shared.Helpers
{
    public static class NetworkHelper
    {
        // Tùy chọn cho JsonSerializer
        private static readonly JsonSerializerOptions _jsonOptions = new JsonSerializerOptions
        {
            PropertyNameCaseInsensitive = true,
            WriteIndented = false
        };

        // Serialize object -> JSON -> byte[]
        public static byte[] Serialize<T>(T obj)
        {
            string jsonString = JsonSerializer.Serialize(obj, _jsonOptions);
            return Encoding.UTF8.GetBytes(jsonString);
        }

        // Deserialize byte[] -> JSON -> object
        public static T Deserialize<T>(byte[] data)
        {
            string jsonString = Encoding.UTF8.GetString(data);
            return JsonSerializer.Deserialize<T>(jsonString, _jsonOptions);
        }

        // Gửi dữ liệu với độ dài phía trước
        public static async Task SendWithLengthAsync(NetworkStream stream, byte[] data)
        {
            byte[] lenBytes = BitConverter.GetBytes(data.Length);
            await stream.WriteAsync(lenBytes, 0, 4);
            await stream.WriteAsync(data, 0, data.Length);
            await stream.FlushAsync();
        }

        // Nhận dữ liệu với độ dài phía trước
        public static async Task<byte[]> ReceiveWithLengthAsync(NetworkStream stream)
        {
            // Đọc 4 byte đầu (độ dài)
            byte[] lenBytes = new byte[4];
            int read = 0;
            while (read < 4)
            {
                int r = await stream.ReadAsync(lenBytes, read, 4 - read);
                if (r == 0) return null;
                read += r;
            }

            int length = BitConverter.ToInt32(lenBytes, 0);
            if (length <= 0) return null;

            // Đọc dữ liệu
            byte[] data = new byte[length];
            read = 0;
            while (read < length)
            {
                int r = await stream.ReadAsync(data, read, length - read);
                if (r == 0) return null;
                read += r;
            }
            return data;
        }
    }
}