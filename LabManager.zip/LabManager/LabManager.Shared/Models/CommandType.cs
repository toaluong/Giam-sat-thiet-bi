﻿namespace LabManager.Shared.Models
{
    public enum CommandType
    {
        // Client -> Server
        Register,
        Heartbeat,
        ResourceReport,
        ScreenFrame,

        // Server -> Client
        LockScreen,
        UnlockScreen,
        Shutdown,
        ShutdownTimer,
        KillProcess,
        RunApplication,
        ShowNotification,
        ReceiveFile
    }
}