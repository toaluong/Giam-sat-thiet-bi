﻿using System;
using System.Collections.Generic;

namespace LabManager.Shared.Models
{
    [Serializable]
    public class Packet
    {
        public CommandType Command { get; set; }
        public string ClientId { get; set; }
        public object Payload { get; set; }
        public DateTime Timestamp { get; set; } = DateTime.Now;
    }

    [Serializable]
    public class SystemInfo
    {
        public string MachineName { get; set; }
        public string IpAddress { get; set; }
        public string OSVersion { get; set; }
        public int CpuCores { get; set; }
        public long TotalRAM { get; set; }
    }

    [Serializable]
    public class ResourceReport
    {
        public float CPUUsage { get; set; }
        public float RAMUsage { get; set; }
        public float DiskUsage { get; set; }
        public List<string> RunningProcesses { get; set; } = new List<string>();
        public DateTime ReportTime { get; set; } = DateTime.Now;
    }

    [Serializable]
    public class ScreenFrame
    {
        public byte[] ImageData { get; set; }
        public int Width { get; set; }
        public int Height { get; set; }
        public int Quality { get; set; } = 60;
        public DateTime CaptureTime { get; set; }
    }
}